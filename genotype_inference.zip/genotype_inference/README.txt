About the tool
--------------

Dependencies: 
         PLINK, 
         R (optparse, foreach, doParallel)
Options:
         --cores : number of cores to use for computing
         --cutsize : size of subsets
         --out : name of the output file
         --workdir : path of the directory containing the input files and output
Input format:
        PLINK format:
	familyID
	individualID
	fatherID
	motherID
	sex
	affection
	SNPs


Usage
-----
1.Put the script and input files (genotype files .ped and .map) into the same directory
2.Open terminal and move to that folder
3.Command line example :  


		nohup Rscript genoInference.R --file myDataset --cutsize 50 --cores 2 &
